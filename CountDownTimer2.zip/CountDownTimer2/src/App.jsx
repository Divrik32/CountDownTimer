import './App.css'
import CounterTimer from './components/CounterTimer'
import Timer from './components/Timer'
import Timer1 from './components/Timer1'
import TimerCI from './components/TimerCI'

function App() {

  return (
<>
<CounterTimer/>
</>
  )
}

export default App
