import React, { useState, useEffect, useRef } from 'react';

function Timer() {
  const [count, setCount] = useState(0);
  const intervalRef = useRef(null);
  console.log(intervalRef.current);
  
  useEffect(() => {
    // Start the interval when the component mounts
    intervalRef.current = setInterval(() => {
      setCount(prevCount => prevCount + 1); // Increment counter every second
    }, 1000); // Run every 1 second

    // Cleanup function to clear the interval when the component unmounts or stops
    return () => {
      clearInterval(intervalRef.current); // Stop the interval when the component unmounts or stops
    };
  }, []); // Empty dependency array ensures effect runs only once on mount

  // Function to stop the timer manually
  const stopTimer = () => {
    clearInterval(intervalRef.current); // Stop the interval
  };

  return (
    <div>
      <p>Counter: {count}</p>
      <button onClick={stopTimer}>Stop Timer</button>
    </div>
  );
}

export default Timer;
