import React, { useEffect, useRef, useState } from 'react'
import './CounterTimer.css'

const CounterTimer = () => {
  const [time,setTime]=useState(0)
  const [active,setActive]=useState(false)
  const [pause,setPause]=useState(false)
  const intervalRef=useRef(null)
  const handleInput = (e) =>{
    setTime(parseInt(e.target.value * 60))
  }
   const formatTime=()=>{
    const min = String(Math.floor(time/60)).padStart(2,'0')
    const sec = String(time%60).padStart(2,'0')
    return `${min} : ${sec}`
   }
   const handleStart = () => {
      setActive(true)
      setPause(false)
   }
   useEffect(()=>{
    if(active && !pause && time>0){
       intervalRef.current=setInterval(()=>{
         setTime((prev)=>prev-1)
       },1000)
    }else if(time===0){
        clearInterval(intervalRef.current);
        setActive(false);
        alert('Time is up!')
    }
    return ()=> clearInterval(intervalRef.current)
   },[active,pause,time])
   const handlePause=()=>{
    setPause(!pause)
   }
   const handleReset = () =>{
    clearInterval(intervalRef.current)
    setActive(false)
    setPause(true)
    setTime(0)
   }
  return (
    <div className='countdown-timer'>
        <h1>CountDown Timer</h1>
        <div className='counter-timer'>
           <input type="number" placeholder='Enter time in minitues' onChange={handleInput}/>
           <br /><br /><h2>{formatTime()}</h2>
        </div><br />
        <div className='timer-controls'>
           <button onClick={handleStart} disabled={active && !pause}>Start</button>
           <button onClick={handlePause} disabled={!active}>{pause?'Resume':'Pause'}</button>
           <button onClick={handleReset}>Reset</button>

        </div>
    </div>
  )
}

export default CounterTimer