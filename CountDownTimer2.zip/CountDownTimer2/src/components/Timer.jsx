import React, { useState, useEffect, useRef } from 'react';

function Timer() {
  const [count, setCount] = useState(0); // State to track the counter
  const [isRunning, setIsRunning] = useState(false); // State to track if the timer is running
  const intervalRef = useRef(null); // Ref to store interval ID
   console.log(intervalRef.current);
   
  // Effect to handle starting and stopping the interval
  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        setCount((prevCount) => prevCount + 1); // Increment counter
      }, 1000); // Interval set to 1 second
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null; // Reset the ref
      }
    }

    // Cleanup function to clear the interval when the component unmounts
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current); // Clear the interval on unmount
      }
    };
  }, [isRunning]); // The effect depends on the "isRunning" state

  // Function to start the timer
  const startTimer = () => {
    setIsRunning(true); // Set "isRunning" to true to start the timer
  };

  // Function to stop the timer
  const stopTimer = () => {
    setIsRunning(false); // Set "isRunning" to false to stop the timer
  };

  // Function to reset the timer
  const resetTimer = () => {
    setIsRunning(false); // Stop the timer
    setCount(0); // Reset the count to 0
  };

  return (
    <div>
      <p>Counter: {count}</p>
      <button onClick={startTimer} disabled={isRunning}>
        Start Timer
      </button>
      <button onClick={stopTimer} disabled={!isRunning}>
        Stop Timer
      </button>
      <button onClick={resetTimer}>
        Reset Timer
      </button>
    </div>
  );
}

export default Timer;
